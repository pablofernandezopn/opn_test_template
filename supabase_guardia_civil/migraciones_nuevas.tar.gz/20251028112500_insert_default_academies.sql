-- Migration: Insert default academies
--
-- This migration creates the default academies required by the system.
-- The OPN (Oposición Nacional de Policía) academy is set as id=1 as it's
-- referenced as the default in sync_auth_users_to_cms function.

-- Insert default academies
-- Using ON CONFLICT to make this migration idempotent
INSERT INTO public.academies (
    id,
    name,
    slug,
    description,
    is_active,
    created_at,
    updated_at
) VALUES
    (
        1,
        'OPN - Oposición Policía Nacional',
        'opn',
        'Academia para la preparación de oposiciones a Policía Nacional',
        true,
        NOW(),
        NOW()
    )
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    slug = EXCLUDED.slug,
    description = EXCLUDED.description,
    updated_at = NOW();

-- Ensure the sequence is updated to avoid conflicts with future inserts
SELECT setval('public.academies_id_seq', (SELECT MAX(id) FROM public.academies));

-- Add a comment
COMMENT ON TABLE public.academies IS
'Academias o centros de formación. La academia OPN (id=1) es la academia por defecto para nuevos usuarios.';
