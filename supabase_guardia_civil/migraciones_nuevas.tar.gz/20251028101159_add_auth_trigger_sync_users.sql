-- Migration: Add auth trigger to sync users from auth.users to cms_users
--
-- This trigger automatically syncs users from auth.users to cms_users
-- Note: The auth schema is not included in Supabase backups by default,
-- so this trigger must be recreated via this migration.
--
-- The function public.sync_auth_users_to_cms() must exist previously.

-- Drop trigger if it already exists (for idempotence)
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Create the trigger on auth.users
-- This trigger executes after each INSERT, UPDATE or DELETE on auth.users
-- It automatically syncs users to cms_users with academy_id = 1 (OPN) as default
CREATE TRIGGER on_auth_user_created
  AFTER INSERT OR UPDATE OR DELETE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.sync_auth_users_to_cms();