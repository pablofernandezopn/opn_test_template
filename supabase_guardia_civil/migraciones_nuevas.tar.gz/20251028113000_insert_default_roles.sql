-- Migration: Insert default roles
--
-- This migration creates the default roles required by the system.
-- Role id=4 (User/Alumno) is referenced as the default in sync_auth_users_to_cms function.

-- Insert default roles
-- Using ON CONFLICT to make this migration idempotent
INSERT INTO public.role (
    id,
    role_name,
    created_at,
    updated_at
) VALUES
    (1, 'Admin', NOW(), NOW()),
    (2, 'Editor', NOW(), NOW()),
    (3, 'Tutor', NOW(), NOW()),
    (4, 'User', NOW(), NOW())
ON CONFLICT (id) DO UPDATE SET
    role_name = EXCLUDED.role_name,
    updated_at = NOW();

-- Ensure the sequence is updated to avoid conflicts with future inserts
SELECT setval('public.role_id_seq', (SELECT MAX(id) FROM public.role));

-- Add comments
COMMENT ON TABLE public.role IS
'Roles de usuario en el sistema. El rol User (id=4) es el rol por defecto para nuevos usuarios registrados.';
