-- Migration: Fix permissions for sync_auth_users_to_cms function
--
-- This migration fixes permission issues when creating users from the Supabase dashboard.
-- The sync_auth_users_to_cms function needs explicit permissions to:
-- 1. Access the auth schema
-- 2. Read from auth.users table
-- 3. Insert/update into cms_users table

-- In Supabase, the auth schema is special and managed by supabase_auth_admin
-- The key is to ensure the function runs with the correct security context

-- Ensure the function has proper ownership
-- Using postgres as owner gives it superuser privileges to bypass RLS
ALTER FUNCTION public.sync_auth_users_to_cms() OWNER TO postgres;

-- Grant EXECUTE permission to all roles that might trigger user creation
GRANT EXECUTE ON FUNCTION public.sync_auth_users_to_cms() TO postgres;
GRANT EXECUTE ON FUNCTION public.sync_auth_users_to_cms() TO supabase_auth_admin;
GRANT EXECUTE ON FUNCTION public.sync_auth_users_to_cms() TO service_role;
GRANT EXECUTE ON FUNCTION public.sync_auth_users_to_cms() TO authenticated;
GRANT EXECUTE ON FUNCTION public.sync_auth_users_to_cms() TO anon;

-- Ensure postgres has full permissions on cms_users table and sequence
-- This is critical for the SECURITY DEFINER function to insert/update
GRANT ALL ON TABLE public.cms_users TO postgres;
GRANT ALL ON SEQUENCE public.cms_users_id_seq TO postgres;

-- Also ensure supabase_auth_admin can execute (it's the owner of auth.users)
GRANT ALL ON TABLE public.cms_users TO supabase_auth_admin;
GRANT ALL ON SEQUENCE public.cms_users_id_seq TO supabase_auth_admin;

-- Add a comment explaining the security context
COMMENT ON FUNCTION public.sync_auth_users_to_cms() IS
'Trigger function to sync users from auth.users to cms_users.
Runs with SECURITY DEFINER as postgres to bypass RLS and permission checks.
The function is executed by triggers on auth.users (owned by supabase_auth_admin).
Multiple roles have EXECUTE permission to ensure compatibility with dashboard user creation.';
